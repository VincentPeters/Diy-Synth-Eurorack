/*
 * Simple MIDI receiver
 * Based on https://github.com/boourns/AVRMIDI
 * by Gerb Sterrenburg
 */

#include <avr/io.h>
#include <util/delay.h>

#include <Arduino.h>
#include "MIDI.h"

unsigned char midiState;
unsigned char midiEvent[3];
unsigned char midiReadIndex;
unsigned char midiBytesToIgnore;

#define NUM_MIDI_EVENTS 18

unsigned char midiEventLength[NUM_MIDI_EVENTS][2] = {
    {MIDI_NOTE_OFF,3},
    {MIDI_NOTE_ON,3},
    {MIDI_POLY_TOUCH,3},
    {MIDI_CONTROL_CHANGE,3},
    {MIDI_PROGRAM_CHANGE,2},
    {MIDI_CHANNEL_TOUCH,2},
    {MIDI_PITCH_BEND,3},
    {MIDI_MTC,2},
    {MIDI_SPP,3},
    {MIDI_SONG_SEL,2},
    {MIDI_TUNE_REQ,1},
    {MIDI_CLOCK,1},
    {MIDI_SYNC,1},
    {MIDI_START,1},
    {MIDI_STOP,1},
    {MIDI_CONT,1},
    {MIDI_SENSE,1},
    {MIDI_RESET,1}
};

MIDI::MIDI(){
    processEventCallback = 0;
    midiState = MIDI_WAIT;
}

void MIDI::init(){
    UCSR0B |= (1<<RXEN0)  | (1<<TXEN0);
    UCSR0C |= (1<<UCSZ00) | (1<<UCSZ01);
    UBRR0H  = (BAUD_PRESCALLER >> 8);
    UBRR0L  = BAUD_PRESCALLER;

    //Serial.begin(BAUDRATE);
}

void MIDI::poll(){
    unsigned char byte, tmp;

    // wait until a byte is ready to read
    while( ( UCSR0A & ( 1 << RXC0 ) ) == 0 ){}
    
    // grab the byte from the serial port
    byte = UDR0;

    // state machine for parsing the byte
    switch(midiState) {
        case MIDI_WAIT:
            if (byte == 0xF0){
                // start of sysex
                // call sysex handler, which will return the state we should be in.
                midiState = MIDI_WAIT;
                break;
            }

            // store length of midi command
            tmp = commandLen(byte);
            // is the message one byte long?
            if (tmp == 1) {
                if (processEventCallback != 0){
                    processEventCallback(byte, 0, 0);
                }
            } else if (tmp == 0) {
                // ignore
            } else {
                // save first byte of event, position pointer..
                midiEvent[0] = byte;
                midiReadIndex = 1;

                // go to state READING to read rest of event
                midiState = MIDI_READING;
            }
            break;

        case MIDI_READING:
            midiEvent[midiReadIndex] = byte;
            midiReadIndex++;

            if (midiReadIndex == commandLen(midiEvent[0] & 0xF0)){
                if (processEventCallback != 0){
                    processEventCallback(midiEvent[0], midiEvent[1], midiEvent[2]);
                }

                midiState = MIDI_WAIT;
            }
            break;

        case MIDI_IGNORING:
            if (byte == 0xF7){
                midiState = MIDI_WAIT;
            }
            break;
    }
}

void MIDI::setCallback(void (*fptr)(unsigned char evt0, unsigned char evt1, unsigned char evt2)){
     processEventCallback = fptr;
}

unsigned char MIDI::commandLen(unsigned char cmd){
    unsigned char i;

    if ((cmd & 0xF0) != 0xF0){
        cmd = cmd & 0xF0;
    }

    for (i = 0; i < NUM_MIDI_EVENTS; i++){
        if (cmd == midiEventLength[i][0]){
            return midiEventLength[i][1];
        }
    }

    return 0;
}

#include <Arduino.h>

#include <SPI.h>
#include <MIDI.h>

#define SLAVE_SELECT      2   // PB2

#define MULTIPLEX_CH_A    2   // PD2
#define MULTIPLEX_CH_B    3   // PD3
#define MULTIPLEX_CH_C    4   // PD4

#define TRIGGER           5   // PD5
#define LED_FEEDBACK      7   // PD7

#define TRIGGER_TIME      4   // trigger time in ms

void processMidiEvent(unsigned char evt0, unsigned char evt1, unsigned char evt2);
void setDigitalPot(int value);
void setOutputGate(char gate);

char selected_midi_channel = 0;
char note_map[8] = {7, 6, 4 ,3, 5, 2, 8, 1};

MIDI midi = MIDI();

void setup() {
    // reset PORTC
    DDRC = DDRC | 0b11111111;
    PORTC = 0;

    // set pin modes
    DDRB = DDRB | 0b00000010;
    DDRC = DDRC | 0b00000000;
    DDRD = DDRD | 0b10111100;

    // initialize SPI:
    SPI.begin();
    SPI.setClockDivider(SPI_CLOCK_DIV128);

    // set the midi channel by reading PC0-PC3
    selected_midi_channel = PINC;

    // init MIDI
	midi.init();
	midi.setCallback(processMidiEvent);

    // flash the LED
    PORTD |= 1 << LED_FEEDBACK;
    _delay_ms(20);
    PORTD &= ~(1 << LED_FEEDBACK);
}

void loop() {
    // poll the midi
    midi.poll();
}

void processMidiEvent(unsigned char evt0, unsigned char evt1, unsigned char evt2){
    if(evt0 != MIDI_SENSE){
		unsigned char channel = evt0 & 0x0F;

        // only listen if note is on selected channel
        if(channel == selected_midi_channel){
            unsigned char command = evt0 & 0xF0;

            // only listen if this is a MIDI_NOTE_ON command
            if(command == MIDI_NOTE_ON){
                unsigned char note = evt1 - 60;
                // we listen to C3 to G3

                if(note >= 0 && note < 8){
                    // set LED high
                    PORTD |= 1 << LED_FEEDBACK;

                    // set the correct output gate
                    setOutputGate(note_map[note]);

                    // set the correct output voltage for the trigger
                    setDigitalPot(64 + evt2);

                    // now turn on trigger, wait TRIGGER_TIME and turn it off again
                    PORTD |= 1 << TRIGGER;
                    _delay_ms(TRIGGER_TIME);
                    PORTD &= ~(1 << TRIGGER);

                    // set LED low
                    PORTD &= ~(1 << LED_FEEDBACK);
                }
            }
        }
	}
}

void setDigitalPot(int value) {
    PORTB &= ~(1 << SLAVE_SELECT);
    SPI.transfer(0);
    SPI.transfer(value);
    PORTB |= 1 << SLAVE_SELECT;
}

void setOutputGate(char gate){
    bool ch_a = gate & (1 << 0);
    bool ch_b = gate & (1 << 1);
    bool ch_c = gate & (1 << 2);

    // lower them all
    PORTD &= ~(1 << MULTIPLEX_CH_A);
    PORTD &= ~(1 << MULTIPLEX_CH_B);
    PORTD &= ~(1 << MULTIPLEX_CH_C);

    // if needed, set channel to high
    if(ch_a){
    	 PORTD |= 1 << MULTIPLEX_CH_A;
    }

    if(ch_b){
    	 PORTD |= 1 << MULTIPLEX_CH_B;
    }

    if(ch_c){
    	 PORTD |= 1 << MULTIPLEX_CH_C;
    }
}
